# superpowers-dsh

Superpowers for the **DeepSeek Harness**: a plugin bundle that ports the core
skills of [obra/superpowers](https://github.com/obra/superpowers) (the
Claude-Code skills library: TDD, debugging, planning, collaboration patterns)
to DSH's Cordis plugin architecture.

The plugin registers a skill provider into the **host layer** of the
`ctx.skills` registry, so every agent preset's scope chain merges these
skills. Skill bodies ship inside the package (`skills/<name>/SKILL.md`) and
are located from `import.meta.url` — an assembly fact of the package, never
user configuration.

## Install

```sh
# from the plugin checkout's parent directory (or any directory)
dsh plugin --profile web add <path-to-this-package>
```

`dsh plugin` runs pnpm in the profile directory, then reconciles
`dsh.profile.bundles`: a dependency whose package.json declares
`dsh.bundle` (this one does) joins the layer stack automatically.

Then **restart the web profile** (stop and re-run `dsh web`) so the new
bundle layer mounts. The skills appear in every agent's skill catalog and can
be loaded with the `skill` tool.

### Uninstall

```sh
dsh plugin --profile web remove superpowers-dsh
```

### Verify

```sh
dsh --profile web --dump-config   # the `superpowers` row should be present
```

## Skills

| Skill | Purpose |
| --- | --- |
| `using-superpowers` | How to find and use skills; the entry-point skill |
| `brainstorming` | Turn ideas into designs through collaborative dialogue |
| `writing-plans` | Write comprehensive implementation plans from specs |
| `executing-plans` | Execute a written plan with review checkpoints |
| `subagent-driven-development` | Dispatch fresh subagents per task with reviews |
| `dispatching-parallel-agents` | Fan independent work out across parallel agents |
| `systematic-debugging` | Root-cause-first debugging discipline |
| `test-driven-development` | RED-GREEN-REFACTOR implementation loop |
| `verification-before-completion` | Evidence before success claims |
| `requesting-code-review` | Get rigorous review before merging |
| `receiving-code-review` | Verify feedback instead of blindly implementing it |
| `finishing-a-development-branch` | Integrate completed work safely |
| `using-git-worktrees` | Isolated workspaces for feature work |
| `writing-skills` | Author and validate new skills TDD-style |

## How it works

- **Bundle layer** — `cordis.patch.yml` inserts one row
  (`- id: superpowers-dsh, name: superpowers-dsh`) over the dsh-base layer.
  Later layers (the profile's `cordis.patch.yml`, `--patch` overlays) can
  still address that row by id.
- **Provider** — `lib/index.js` calls `ctx.skills.registerProvider(...)`
  with a provider that:
  - `list()` scans the package's `skills/` directory for
    `<name>/SKILL.md` bundles and returns candidates parsed from YAML
    frontmatter (`name`, `description`, `whenToUse`).
  - `get()` reads the winning candidate's body on demand and returns a
    full skill definition with `resourceBase` pointing at the skill's
    directory, so relative references (scripts, prompt templates) resolve.
- **Zero runtime dependencies** — the plugin imports only Node built-ins and
  consumes the injected `ctx.skills` service interface.

## Porting notes (vs. upstream obra/superpowers)

- Namespace prefixes removed: `superpowers:brainstorming` → `brainstorming`
  (DSH skills are addressed by bare name).
- `using-superpowers` now documents the DSH `skill` tool and points at
  `skills/using-superpowers/references/dsh-tools.md`, a full Claude-Code →
  DSH tool mapping (`pwsh`, `subagent`, `workflow`, `goal`, ...).
- Subagent references map to DSH's `subagent` / `subagent_fork` tools.
- `brainstorming`'s visual companion adds a Windows note: the Node server
  (`scripts/server.cjs`) runs everywhere; the `.sh` helpers are bash-only.

## Adding your own skills

Drop a new `skills/<kebab-name>/SKILL.md` into this package — it must start
with a YAML frontmatter block (`name` + `description`, optionally
`whenToUse`). No code change needed: `list()` discovers it automatically.

## License

MIT. Skill content adapted from
[obra/superpowers](https://github.com/obra/superpowers) (MIT), © Jesse Vincent
and contributors.
